import React, { useEffect } from "react";
import { View, Text, StyleSheet, TouchableOpacity, Platform } from "react-native";
import colors from "../../constants/Colors";
import AlertIcon from "../../../assets/alert.svg";
import Info from "../../../assets/Info.svg"
import { LinearGradient } from "react-native-linear-gradient";
import PropTypes from 'prop-types';


const ToastMessage = ({ actions, title, message, type }) => {
  const isInfo= type === 'info'
  const borderColorError = colors.primaryColors.bloodRed
  const GRADIENT_COLORS = ['#ffeded', '#fff8f8', '#fffefe'];
  const GRADIENT_COLORS_INFO = ['#f2f9ffff', '#fbfcfdff', '#fdfdfdff'];
  const renderActions = () => {
    if (actions?.length === 1) {
      // Inline single action
      return (
        <TouchableOpacity
          style={[styles.actionBtn, styles.secondaryBtn,actions[0]?.disabled && { opacity: 0.5 }]}
          onPress={() => {
            if (!actions[0]?.disabled) {
              actions[0]?.onPress?.();
            }
          }}
          disabled={actions[0]?.disabled}
        >
          <Text style={[styles.actionText, styles.secondaryText]}>
            {actions[0]?.label}
          </Text>
        </TouchableOpacity>
      );
    }

    if (actions?.length > 1) {
      return (
        <View style={styles.actionsRow}>
          {actions.map((action, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.actionBtn,
                index === 0 ? styles.secondaryBtn : styles.primaryBtn,
              ]}
              onPress={() => {
                action.onPress?.();

              }}
            >
              <Text
                style={[
                  styles.actionText,
                  index === 0 ? styles.secondaryText : styles.primaryText,
                ]}
              >
                {action.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      );
    }

    return null;
  };

  return (
    <View style={[styles.outerContainer,{borderColor: isInfo ? colors.primaryColors.borderBlue : borderColorError},]}>
      <LinearGradient
        colors={ isInfo ? GRADIENT_COLORS_INFO :GRADIENT_COLORS}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={styles.gradient}
      >

        <View style={{ flex: 1, padding: Platform.OS == 'ios' ? 14 : 0 }}>
          <View style={styles.rowBetween}>
            <View style={[styles.iconBox,{ padding: isInfo ? 2 : 6, shadowColor: isInfo ? colors.primaryColors.borderBlue : borderColorError}]}>
              {isInfo ? <Info width={30} height={30} /> :<AlertIcon width={20} height={20} />}
            </View>
            <View style={{ flex: 1 }}>

              {title && <Text style={[styles.title, { color: borderColorError }]}>{title}</Text>}
              {message && <Text style={styles.message}>{message}</Text>}
            </View>
            {actions?.length === 1 && renderActions()}
          </View>
          {actions?.length > 1 && renderActions()}
        </View>
      </LinearGradient>
    </View>
  );
};
const styles = StyleSheet.create({
  outerContainer: {
    marginHorizontal: 16,
    borderWidth: 1,
    borderColor: colors.primaryColors.bloodRed,
    borderRadius: 8,
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
    zIndex: 1000,
    overflow: "hidden",
  },
  gradient: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: Platform.OS == 'ios' ? 0 : 14,
    paddingHorizontal: Platform.OS == 'ios' ? 0 : 14,
    borderRadius: 5,
    width: '100%',
  },
  title: {
    fontSize: 16,
    fontWeight: "bold",
  },
  message: {
    fontSize: 14,
    color: "#333",
  },
  iconBox: {
    marginRight: 12,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 6,
    borderRadius: 25,
    backgroundColor: colors.primaryColors.white,
    shadowColor: colors.primaryColors.bloodRed,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: Platform.OS == 'ios' ? 0.35 : 1,
    shadowRadius: 12,
    elevation: 4,
    marginVertical:Platform.OS == 'ios' ? 0 : 8,
  },
  rowBetween: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  actionBtn: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 20,
    borderWidth: 1,
    marginLeft: 8,
    marginRight: Platform.OS == 'ios' ? 0 : 20,
  },
  secondaryBtn: {
    backgroundColor: colors.primaryColors.white,
    borderColor: colors.lightNeutrals.n80,
  },
  actionText: {
    fontSize: 14,
    fontWeight: "700",
  },
  secondaryText: {
    color: colors.primaryColors.charcoalGray,
  },
  primaryBtn: {
    backgroundColor: colors.primaryColors.surface,
    borderColor: colors.primaryColors.surface,
  },
  primaryText: {
    color: colors.primaryColors.white,
  },
  actionsRow: {
    flexDirection: "row",
    justifyContent: "flex-end",
    marginTop: 12,
    gap: 2,
  },
});
ToastMessage.propTypes = {
  title: PropTypes.string.isRequired,
  message: PropTypes.string,
  actions: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string.isRequired,
      onPress: PropTypes.func,
      disabled: PropTypes.bool,
    })
  ),
  type: PropTypes.oneOf(['info', 'warning', 'error']),
};
export default ToastMessage;
