import React, { useCallback, useEffect, useRef } from "react";
import {
  FlatList,
  StyleSheet,
  View,
  Text,
  Animated,
  Platform,
} from "react-native";
import { SlideInLeft, SlideInRight } from 'react-native-reanimated';
import ChatBubble from "../molecules/ChatBubble";
import { shallowEqual, useSelector, useDispatch } from "react-redux";
import ChatDateSeparator from "../atoms/ChatDateSeparator";
import { spacing, size } from "../../constants/Dimensions";
import PropTypes from "prop-types";
import MessageBanner from "../atoms/MessageBanner";
import { socketConstants, stringConstants } from "../../constants/StringConstants";
import { fontStyle } from "../../constants/Fonts";
import ChatSkeletonLoader from "../atoms/ChatSkeletonLoader";
import ToastMessage from "../atoms/ToastMessage";
import { encryptSocketPayload } from "../../common/cryptoUtils";
import { CHAT_MESSAGE_PROXY } from "../../config/apiUrls";
import { useNetInfo } from "@react-native-community/netinfo";
import { getMessageStatus } from "../../common/utils";
import { retryMessage, updateMessageStatus } from "../../store/reducers/chatSlice";
import UnreadMessageBanner from "../atoms/UnreadMessageBanner";

const MessageItem = React.memo(({
  item,
  index,
  messages,
  formatTime,
  setDropDownType,
  setMessageObjectId,
  handleReplyMessage,
  token,
  setReplyIndex,
  copyToClipboard,
  socket,
  reconfigApiResponse,
  setCopied,
  env,
  removeUnreadMessage,
}) => {
  const replyMessageObj = React.useMemo(() =>
    item?.replyId ? messages.find((msg) => msg?.messageId === item.replyId) : null,
    [item.replyId, messages]
  );

  const replyMessage = replyMessageObj?.message?.text || replyMessageObj?.text || null;
  const replyFrom = replyMessageObj?.messageTo.toLowerCase() || "";
  const isBot = item?.messageTo?.toLowerCase() === stringConstants.user;

    const slideAnim = useRef(new Animated.Value(isBot ? -50 : 50))?.current; // start offset
    const opacity = useRef(new Animated.Value(0)).current;
 
    useEffect(() => {
      Animated.spring(slideAnim, {
        toValue: 0,
        damping: 15,
        stiffness: 120,
        useNativeDriver: true,
      }).start();
 
      Animated.timing(opacity, {
        toValue: 1,
        duration: 250,
        useNativeDriver: true,
      }).start();
    }, []);

  return (
    <Animated.View
        style={[
          isBot ? styles.messageContainer : styles.messageContainerUser,
          {
            transform: [{translateX: slideAnim}],
            opacity,
            alignSelf: isBot ? 'flex-start' : 'flex-end',
          },
        ]}>
      <ChatBubble
        text={item?.message?.text || item?.text}
        isBot={isBot}
        time={formatTime(item?.dateTime || item?.createdAt)}
        status={item?.status}
        replyMessage={replyMessage}
        replyFrom={replyFrom}
        index={index}
        media={item.media}
        isCopied={false}
        activity={item.activity}
        botOption={item?.message?.botOption || false}
        options={item?.message?.botOption ? item.message.options : []}
        setDropDownType={setDropDownType}
        setMessageObjectId={setMessageObjectId}
        messageId={item.messageId}
        handleReplyMessage={handleReplyMessage}
        token={token}
        replyIndex={item.replyIndex || 0}
        setReplyIndex={setReplyIndex}
        copyToClipboard={copyToClipboard}
        replyMessageObj={replyMessageObj}
        socket={socket}
        reconfigApiResponse={reconfigApiResponse}
        setCopied={setCopied}
        env={env}
        botCommunicationFlow={item?.botCommunicationFlow}
        removeUnreadMessage={removeUnreadMessage}
      />
    </Animated.View>
  );
  },
);
MessageItem.propTypes = {
  item: PropTypes.object.isRequired,
  index: PropTypes.number.isRequired,
  messages: PropTypes.array.isRequired,
  formatTime: PropTypes.func.isRequired,
  setDropDownType: PropTypes.func.isRequired,
  setMessageObjectId: PropTypes.func.isRequired,
  handleReplyMessage: PropTypes.func.isRequired,
  token: PropTypes.string,
  setReplyIndex: PropTypes.func.isRequired,
  copyToClipboard: PropTypes.func,
  socket: PropTypes.object,
  reconfigApiResponse: PropTypes.object.isRequired,
  setCopied: PropTypes.func.isRequired,
  env: PropTypes.string.isRequired,
  removeUnreadMessage: PropTypes.func.isRequired,
};
const ChatBody = React.memo(({
  scrollViewRef,
  handleScroll,
  setDropDownType,
  setMessageObjectId,
  handleReplyMessage,
  loadChatHistory,
  page,
  reconfigApiResponse,
  socket,
  copyToClipboard,
  setCopied,
  token,
  setReplyIndex,
  historyLoading,
  hasMore,
  handleScrollEnd,
  env,
  unreadCount,
  firstUnreadMessageId,
  removeUnreadMessage,
}) => {
  ChatBody.propTypes = {
    scrollViewRef: PropTypes.object.isRequired,
    handleScroll: PropTypes.func.isRequired,
    setDropDownType: PropTypes.func.isRequired,
    setMessageObjectId: PropTypes.func.isRequired,
    handleReplyMessage: PropTypes.func.isRequired,
    loadChatHistory: PropTypes.func.isRequired,
    page: PropTypes.number.isRequired,
    reconfigApiResponse: PropTypes.object.isRequired,
    socket: PropTypes.object,
    copyToClipboard: PropTypes.func,
    setCopied: PropTypes.func,
    setReplyIndex: PropTypes.func,
    token: PropTypes.string,
    historyLoading: PropTypes.bool,
    hasMore: PropTypes.bool,
    handleScrollEnd: PropTypes.func,
    env: PropTypes.string.isRequired,
    unreadCount: PropTypes.number,
    firstUnreadMessageId: PropTypes.string,
    removeUnreadMessage: PropTypes.func.isRequired,
  };
const netInfo = useNetInfo();
const dispatch = useDispatch();
  const messages = useSelector((state) => state.chat.messages, shallowEqual);
  const isLoading = useSelector((state) => state.loader.isLoading);

  const formatTime = useCallback((dateTime) => {
    let date;
    if (typeof dateTime === "string") {
      date = new Date(dateTime);
    } else if (typeof dateTime === "number") {
      date = new Date(dateTime * 1000);
    } else {
      return "Invalid Time";
    }
    if (isNaN(date.getTime())) {
      return "Invalid Time";
    }
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }, []);
const formatSeparatorDate = (dateObj) => {
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);

  const isSameDay = (d1, d2) =>
    d1.getDate() === d2.getDate() &&
    d1.getMonth() === d2.getMonth() &&
    d1.getFullYear() === d2.getFullYear();

  if (isSameDay(dateObj, today)) return stringConstants.Today;
  if (isSameDay(dateObj, yesterday)) return stringConstants.Yesterday;

  const weekday = dateObj.toLocaleDateString("en-US", { weekday: "long" });
  const day = dateObj.getDate(); // 5
  const month = dateObj
    .toLocaleDateString("en-US", { month: "short" })
    .toLowerCase(); // feb

  return `${weekday}, ${day} ${month}`;
};
 

  const generateChatDataWithSeparators = useCallback((messages = []) => {
    const result = [];
    const sortedMessages = [...messages].sort((a, b) => {
      const aTime = new Date(a.dateTime || a.createdAt).getTime();
      const bTime = new Date(b.dateTime || b.createdAt).getTime();
      return aTime - bTime;
    });
    let lastDate = "";
    for (const msg of sortedMessages) {
      const rawDate = msg?.dateTime || msg?.createdAt * 1000;
      if (!rawDate) continue;
      const dateObj = new Date(rawDate);
      if (isNaN(dateObj.getTime())) continue;
      const currentDateUTC = dateObj
        .toUTCString()
        .split(" ")
        .slice(0, 4)
        .join(" ");
      if (currentDateUTC !== lastDate) {
        result.push({
          id: `separator-${currentDateUTC}`,
          type: stringConstants.separator,
          date: formatSeparatorDate(dateObj),
        });
        lastDate = currentDateUTC;
      }
      result.push({ ...msg, type: "message" });
      if (msg?.conversationEnded) {

        result.push({
          id: `banner-conversation-ended-${msg.messageId}`,
          type: stringConstants.banner,
          content: {
            text: stringConstants.conversationClosed,
            icon: (
              <Text style={{ fontSize: fontStyle.bodyMediumMedium12.fontSize }}>✅</Text>
            ),
          },
        });
      }
      const isHistoricalMessage = msg.isFromHistory === true;
      if ((msg.status === socketConstants.failed || msg.status === socketConstants.pending) && !isHistoricalMessage) {
        result.push({
          id: `error-toast-${msg.messageId}`,
          type: "inline_error_toast",
          errorMessage: msg.errorMessage || "Failed to send message.",
          errorCode: msg.errorCode,
          messageId: msg.messageId,
          showRetry: msg.status === socketConstants.pending,
        });
      }

    }
    return result;
  }, []);
const chatWithSeparators = React.useMemo(() => {
  const base = generateChatDataWithSeparators(messages); // already sorted oldest→newest
  if (!firstUnreadMessageId) return base;

  const idx = base.findIndex(
    item => item.type === "message" && item.messageId === firstUnreadMessageId
  );
  if (idx === -1) return base;

  const clone = [...base];
  clone.splice(idx, 0, {
    id: `unread-separator-${firstUnreadMessageId}`,
    type: "unread_separator",
    count: unreadCount,
  });
  return clone;
}, [messages, firstUnreadMessageId, unreadCount]);

  const retrySendMessage = (messageId) => {
    const messageToRetry = messages.find(msg => msg.messageId === messageId);
    if (!messageToRetry) return;
    const status = getMessageStatus(netInfo, socket);
     dispatch(retryMessage({
      messageId: messageId,
      status: status,
      newDateTime: new Date().toISOString()
    }));
    const retryPayload = {
      action: CHAT_MESSAGE_PROXY,
      message: {
        emailId: reconfigApiResponse?.userInfo?.email,
        userId: reconfigApiResponse?.userInfo?.agentId,
        messageId: messageToRetry.messageId,
        platform: reconfigApiResponse?.theme?.platform,
        sendType: "MESSAGE",
        messageTo: stringConstants.botCaps,
        messageType: messageToRetry.messageType || "text",
        text: messageToRetry.message?.text || messageToRetry.text,
        replyToMessageId: messageToRetry.replyId,
      }
    };
    if (socket && socket.readyState === WebSocket.OPEN) {
      const encryptedPayload = encryptSocketPayload(retryPayload.message,env);
      const finalPayload = {
        action: CHAT_MESSAGE_PROXY,
        token: token,
        payload: encryptedPayload
      };
      socket.send(JSON.stringify(finalPayload));
    
   }
  }
  const renderItem = useCallback(({ item, index }) => {
    if (item.type === stringConstants.separator) {
      return <ChatDateSeparator date={item.date} />;
    }
    if (item.type === stringConstants.banner) {
      return (
        <View
          style={{
            marginHorizontal: spacing.space_m4,
            marginVertical: spacing.space_10,
          }}
        >
          <MessageBanner
            key={item.id}
            text={item.content.text}
            icon={item.content.icon}
          />
        </View>
      );
    }
     if (item.type === "unread_separator") {
    if (!item.count) return null;
    return (
     <UnreadMessageBanner count={item.count} />
    );
  }
    if (item.type === "inline_error_toast") {
      const showRetry = item.showRetry;
      return (
        <View style={{ marginBottom: 4 }}>
          <ToastMessage
            visible={true}
            title={showRetry? "Message Delivery Failed": "Something went wrong on our end!"}
            message={""}
            actions={
              showRetry
            ? [
                {
                  label: "Retry",
                  onPress: () => retrySendMessage(item.messageId),
                  disabled: isLoading,
                },
              ]
            : []}
          />
        </View>
      );
    }

    return (
      <MessageItem
        item={item}
        index={index}
        messages={messages}
        env={env}
        formatTime={formatTime}
        setDropDownType={setDropDownType}
        setMessageObjectId={setMessageObjectId}
        handleReplyMessage={handleReplyMessage}
        token={token}
        setReplyIndex={setReplyIndex}
        copyToClipboard={copyToClipboard}
        socket={socket}
        reconfigApiResponse={reconfigApiResponse}
        setCopied={setCopied}
        removeUnreadMessage={removeUnreadMessage}
      />
    );
  }, [
    messages,
    formatTime,
    setDropDownType,
    setMessageObjectId,
    handleReplyMessage,
    token,
    setReplyIndex,
    copyToClipboard,
    socket,
    reconfigApiResponse,
    setCopied,
    removeUnreadMessage,
  ]);

  return (
    <FlatList
      ref={scrollViewRef}
      data={[...chatWithSeparators].reverse()}
      renderItem={renderItem}
      keyExtractor={(item) => item.id || item.messageId}
      contentContainerStyle={styles.chatBodyContent}
      showsVerticalScrollIndicator={true}
      inverted={true}
      scrollEventThrottle={16}
      windowSize={21}
      bounces={false}
      onScroll={handleScroll}
      onEndReachedThreshold={0.5}
      onEndReached={() =>
        hasMore && !historyLoading && reconfigApiResponse?.userInfo?.agentId &&
        loadChatHistory(reconfigApiResponse?.userInfo?.agentId, page, 5, token)
      }
      onMomentumScrollEnd={handleScrollEnd}

      initialNumToRender={5}
      removeClippedSubviews={true}
      maxToRenderPerBatch={5}
      updateCellsBatchingPeriod={50}
      ListHeaderComponent={
        isLoading ? (
          <View style={styles.messageContainer}>
            <ChatBubble
              text={""}
              isBot={true}
              isLoader={isLoading}
              replyMessage={""}
              replyFrom={""}
              index={0}
              messageId={""}
            />
          </View>
        ) : null
      }
      ListFooterComponent={
        historyLoading ? (
          <View style={styles.historyLoaderContainer}>
            <ChatSkeletonLoader />
          </View>
        ) : null
      }
    />
  );
});
const styles = StyleSheet.create({
  chatBodyContent: {
    paddingBottom: spacing.space_m3,
    paddingTop: spacing.space_10,
  },
  messageContainer: {
    width: size.hundredPercent,
    paddingVertical: spacing.space_10,
    paddingLeft: spacing.space_s3,
    paddingBottom: spacing.space_m3,
    alignItems: "flex-start",
  },
  messageContainerUser: {
    width: size.hundredPercent,
    padding: spacing.space_s3,
    alignItems: "flex-end",
  },


});
export default ChatBody;
