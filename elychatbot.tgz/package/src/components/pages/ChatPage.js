import React, { useState, useRef, useEffect, useCallback, useMemo, use } from "react";
import {
  View,
  StyleSheet,
  StatusBar,
  KeyboardAvoidingView,
  Platform,
  AppState,

} from "react-native";
import { ChatHeader } from "../organims/ChatHeader";
import ChatFooter from "../organims/ChatFooter";
import ChatBody from "../organims/ChatBody";
import FabFloatingButton from "../atoms/FabFloatingButton";
import { LandingPage } from "../organims/LandingPage";
import Clipboard from "@react-native-clipboard/clipboard";
import { useDispatch, useSelector, shallowEqual } from "react-redux";
import { addChatHistory, clearMessages, addMessage, updateMessageStatus } from "../../store/reducers/chatSlice";
import { useNavigation } from "@react-navigation/native";
import { showLoader, hideLoader } from "../../store/reducers/loaderSlice";
import { SafeAreaView } from "react-native-safe-area-context";
import { getData } from "../../store/actions";
import { fetchChatHistory } from "../../config/api/chatHistory";
import colors from "../../constants/Colors";
import { flex, spacing } from "../../constants/Dimensions";
import { splitMarkdownIntoTableAndText, formatBotMessage, formatHistoryMessage } from "../../common/utils";
import { platformName, socketConstants, stringConstants, timeoutConstants } from "../../constants/StringConstants";
import VideoLoader from "../atoms/VideoLoader";
import { validateJwtToken } from "../../config/api/ValidateJwtToken";
import { getWebSocketBaseUrl } from "../../constants/constants";
import PropTypes from "prop-types";
import { CHAT_MESSAGE_PROXY } from "../../config/apiUrls";
import { encryptSocketPayload, decryptSocketPayload } from "../../common/cryptoUtils";
import { useNetInfo } from "@react-native-community/netinfo";
import ErrorModal from "../atoms/ErrorModal";
export const ChatPage = ({ route }) => {
  const {
    jwtToken,
    userInfo,
    platform,
    env="uat",
  } = route?.params || {};
  const MAX_TOKEN_RETRIES = 1;
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const [copied, setCopied] = useState(false);
  const scrollViewRef = useRef(null);
  const isAtBottomRef = useRef(true);
  const responseTimeoutRef = useRef(null);
  const reconfigApiResponseRef = useRef({});
  const tokenRef = useRef(token);
  const isAutoScrollingRef = useRef(false);
  const lastBackgroundTimeRef = useRef(null);
  const tokenExpiryRetryCountRef = useRef(0);
  const [dropDownType, setDropDownType] = useState("");
  const [messageObjectId, setMessageObjectId] = useState(null);
  const [replyMessageId, setReplyMessageId] = useState(null);
  const [navigationPage, setnavigationPage] = useState("");
  const [reply, setReply] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  const [replyIndex, setReplyIndex] = useState(0);
  const [reconfigApiResponse, setReconfigApiResponse] = useState({});
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [inactivityTimer, setInactivityTimer] = useState(null);
  const [token, settoken] = useState("");
  const [historyLoading, sethistoryLoading] = useState(false);
  const [keyboardHeight, setKeyboardHeight] = useState("");
  const [fabState, setFabState] = useState({ showFab: false, showNewMessageAlert: false, newMessageCount: 0 });
  const [modalData, setModalData] = useState({
    visible: false,
    title: "",
    message: "",
    buttonText: "",
  });
  const [socket, setSocket] = useState(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [firstUnreadMessageId, setFirstUnreadMessageId] = useState(null);
  const messages = useSelector((state) => state.chat.messages, shallowEqual);
  const ws = useRef(null);
  const backgroundColor = reconfigApiResponse?.theme?.backgroundColor || colors.primaryColors.lightSurface;
  const isSharing = useSelector((state) => state.shareLoader.isSharing);
  const netInfo = useNetInfo();

  useEffect(() => {
    reconfigApiResponseRef.current = reconfigApiResponse;
  }, [reconfigApiResponse]);
  useEffect(() => {
    tokenRef.current = token;
  }, [token]);
  const messageObject = useMemo(() =>
    messages.find(msg => msg?.messageId === messageObjectId),
    [messages, messageObjectId]
  );
  const startResponseTimeout = useCallback(() => {
    if (responseTimeoutRef.current) {
      clearTimeout(responseTimeoutRef.current);
    }
    responseTimeoutRef.current = setTimeout(() => {
      dispatch(hideLoader());
      responseTimeoutRef.current = null;
    }, timeoutConstants.response);
  }, [dispatch]);

  const clearResponseTimeout = useCallback(() => {
    if (responseTimeoutRef.current) {
      clearTimeout(responseTimeoutRef.current);
      responseTimeoutRef.current = null;
    }
  }, []);

  const SCROLL_BOTTOM_THRESHOLD = 20;
  const handleScroll = useCallback(({ nativeEvent }) => {
    const { contentOffset } = nativeEvent;

    // Because list is inverted, bottom = y <= threshold
    const isBottom = contentOffset.y <= SCROLL_BOTTOM_THRESHOLD;
    isAtBottomRef.current = isBottom;

    // Don’t completely block during auto-scroll, just mark bottom state
    if (!isAutoScrollingRef.current) {
      if (isBottom) {
        resetNewMessageState();
      } else {
        setFabState(prev => ({
          ...prev,
          showFab: true,
          showNewMessageAlert: prev.showNewMessageAlert,
          newMessageCount: prev.newMessageCount,
        }));
      }
    }


  }, []);
  const showErrorModal = (title, message, buttonText = " ") => {
    setModalData({
      visible: true,
      title,
      message,
      buttonText,
    });
  };

  const hideModal = () => {
    setModalData((prev) => ({ ...prev, visible: false }));
  };

  const handleReplyMessage = useCallback(() => {
    if (messageObjectId) {
      setReplyMessageId(messageObjectId);
      setReply(true);
    }
  }, [messageObjectId]);
  const resetNewMessageState = useCallback(() => {
    setFabState({ showFab: false, showNewMessageAlert: false, newMessageCount: 0 });
  }, []);
  const scrollToDown = useCallback(() => {
    if (scrollViewRef.current) {
      isAutoScrollingRef.current = true;
      scrollViewRef.current.scrollToOffset({
        offset: 0,
        animated: true,
      });
      // Reset after short delay so user scrolls aren’t blocked
      setTimeout(() => {
        isAutoScrollingRef.current = false;
      }, 300);
    }
  }, []);
  const showErrorModalTokenExpiry = () => {
    showErrorModal(stringConstants.failedToLogin, stringConstants.unableToAuthenticate,stringConstants.goBack)
  }
  const getIsAtBottom = (contentOffset) => contentOffset.y <= SCROLL_BOTTOM_THRESHOLD;
  const onMomentumScrollEnd = ({ nativeEvent }) => {
    const isBottom = getIsAtBottom(nativeEvent.contentOffset);
    if (isAutoScrollingRef.current && isBottom) {
      resetNewMessageState();
      isAutoScrollingRef.current = false;
    }
    if (!isAutoScrollingRef.current && isBottom) {
      resetNewMessageState();
    }
  };
  const loadChatHistory = async (agentId, page, message, currentToken, isRetry = false) => {

    if (!isRetry && tokenExpiryRetryCountRef.current > MAX_TOKEN_RETRIES) {
      showErrorModalTokenExpiry();
      return;
    }

    setHasMore(true);
    if (!hasMore) return;

    try {
      sethistoryLoading(true);
      const newMessages = await fetchChatHistory(agentId, page, message, currentToken, tokenExpiryRetryCountRef.current,platform,env);
      if (!newMessages || newMessages.length === 0) {
        setHasMore(false);
        sethistoryLoading(false);
        return;
      }
      const formattedMessages = newMessages?.content.map(msg =>
        formatHistoryMessage(msg)
      );
      if(page == 0 && formattedMessages.length > 0){
        const deliveredMessages = formattedMessages.filter(msg =>
        msg?.messageTo === stringConstants.user &&
        (msg?.status === socketConstants.delivered || msg?.status === socketConstants.received)
      );
      
      if (deliveredMessages.length > 0) {
        const sorted = [...deliveredMessages].sort((a, b) =>
          new Date(a.dateTime || a.createdAt) - new Date(b.dateTime || b.createdAt)
        );
        setFirstUnreadMessageId(sorted[0].messageId);
      } else {
        setFirstUnreadMessageId(null);
      }
      setUnreadCount(deliveredMessages.length);
    }
      
      tokenExpiryRetryCountRef.current = 0;
      dispatch(addChatHistory(formattedMessages));
      setPage((prev) => prev + 1);
      sethistoryLoading(false);

    } catch (err) {
      sethistoryLoading(false);

      if (err.message === stringConstants.tokenExpired && tokenExpiryRetryCountRef.current < MAX_TOKEN_RETRIES) {
        try {
          const refreshedToken = await validateJwt(); // validateJwtToken inside
          tokenExpiryRetryCountRef.current += 1;

          // retry only once with new token
          await loadChatHistory(agentId, page, message, refreshedToken, true);
        } catch (refreshError) {
          showErrorModalTokenExpiry();
        }
      } else {
        // second time or other error
        setHasMore(false)
        console.error(stringConstants.failToLoad, err);
      }
    }
  };

  const reconnectWebSocket = async () => {
    try {
      const agentId = reconfigApiResponseRef.current?.userInfo?.agentId;
      if (agentId && tokenRef.current) {
        connectWebSocket(agentId, tokenRef.current);
      }
    } catch (error) {
      console.error(stringConstants.webSocketReconnectionFailed, error);
      if (tokenExpiryRetryCountRef.current > MAX_TOKEN_RETRIES) {
        showErrorModalTokenExpiry();
      }
    }
  };
  const connectWebSocket = (agentId, token) => {
    const WEBSOCKET_URL = `${getWebSocketBaseUrl(env)}${agentId}&Auth=${token}&platform=${platform}`;
    if (!agentId || !token) {
      console.error(stringConstants.agentIdOrTokenMissing);
      return;
    }

    ws.current = new WebSocket(WEBSOCKET_URL);

    ws.current.onopen = () => {
      console.log(stringConstants.socketConnected);
      tokenExpiryRetryCountRef.current = 0;
      setSocket(ws.current);
    };
    ws.current.onmessage = (event) => {
      try {
        if (!event.data) return;
        const data = JSON.parse(event.data);
        // Handle encrypted payload
        if (data.payload) {
          const decryptedData = decryptSocketPayload(data,env);
          if (decryptedData.type === socketConstants.error) {
            handleErrorMessage(decryptedData);
          }
          if (decryptedData.type === socketConstants.botResponse) {
            handleBotMessage(decryptedData);
          }
          else if (decryptedData.type === socketConstants.acknowledgement) {
            handleAcknowledgement(decryptedData);
          }
        }
        // Fallback for unencrypted messages (remove in production)
        else {
          console.warn(stringConstants.receivedUnencryptedMessage, data);
          if (data.type === socketConstants.botResponse) {
            handleBotMessage(data);
          }
          else if (data.type === socketConstants.acknowledgement) {
            handleAcknowledgement(data);
          }
        }
      } catch (err) {
        console.error(stringConstants.messageProccessingError, err);
      }
    };
    ws.current.onerror = (error) => {
      clearResponseTimeout();

      // Check if error is due to token expiry (WebSocket error code 1008)
      if (error.code === 1008) {
        handleWebSocketTokenExpiry();
      }
    };

    ws.current.onclose = (e) => {
      console.log(`WebSocket closed: ${e.code} - ${e.reason}`);

      // Check closure is due to token expiry (1008 = policy violation, often token related)
      if (e.code === 1008 || (e.code === 1006 && e.reason !== stringConstants.softwareCausedAbort)) {
        handleWebSocketTokenExpiry();
      }

      cleanupWebSocket();
      setPage(0);
      clearResponseTimeout();

      if (e.code === 1001 && e.reason == socketConstants.goingAway && AppState.currentState === stringConstants.active) {
        reconnectWebSocket();
      }
    };
  };

  const handleWebSocketTokenExpiry = async () => {
    if (tokenExpiryRetryCountRef.current <= MAX_TOKEN_RETRIES) {
      try {
        const newToken = await validateJwt();
        tokenExpiryRetryCountRef.current += 1;

        if (reconfigApiResponseRef.current?.userInfo?.agentId && newToken) {
          connectWebSocket(reconfigApiResponseRef.current.userInfo.agentId, newToken);
        }
      } catch (error) {
        if (error.message === stringConstants.platformTokenExpired || tokenExpiryRetryCountRef.current > MAX_TOKEN_RETRIES || error.message === stringConstants.tokenExpired) {
          showErrorModalTokenExpiry();
        }
      }
    } else {
      showErrorModalTokenExpiry();
    }
  };
  const cleanupWebSocket = (sendDisconnect = false) => {
    if (!ws.current) return;
    try {
      if (sendDisconnect && ws.current.readyState === WebSocket.OPEN) {
        const disconnectPayload = {
          action: socketConstants.disconnect,
          userId: reconfigApiResponseRef.current?.userInfo?.agentId,
          platform: platform,
        };
        console.log(`Disconnecting WebSocket for agentId: ${reconfigApiResponseRef.current?.userInfo?.agentId}`);
        ws.current.send(JSON.stringify(disconnectPayload));
      }
    } catch (error) {
      console.error(error);
    } finally {
      ws.current = null;
      setSocket(ws.current);
    }
  };
  const sendAcknowledgement = (messageId) => {
    if (ws.current && ws.current.readyState === WebSocket.OPEN) {
      const currentConfig = reconfigApiResponseRef.current;
      const payload = {
        messageId: messageId,
        status: socketConstants.read,
        sendType: socketConstants.acknowledgement,
        userId: currentConfig?.userInfo?.agentId,
        emailId: currentConfig?.userInfo?.email,
        platform: currentConfig?.theme?.platform,
      };
      const encryptedPayload = encryptSocketPayload(payload, env);
      const finalPayload = {
        action: CHAT_MESSAGE_PROXY,
        token: token,
        payload: encryptedPayload
      };
      ws.current.send(JSON.stringify(finalPayload));
    }
  };
  const validateJwt = async (isInitialCall = false) => {
    try {

      const validationResponse = await validateJwtToken(
        jwtToken,
        platform,
        {
          agentId: userInfo?.agentId,
          userName: userInfo?.userName,
          email: userInfo?.email,
          role: userInfo?.role,
          firebaseId: userInfo?.firebaseId,
          deviceId: userInfo?.deviceId,
        },
        env
      );
      if (!validationResponse || validationResponse.status !== stringConstants.success) {
        throw new Error(stringConstants.tokenValidationFailed);
      }

      const newToken = validationResponse?.data?.elyAuthToken;
      settoken(newToken);
      if (isInitialCall) {
        tokenExpiryRetryCountRef.current = 0;
      }
      return newToken;
    } catch (error) {
      console.error(stringConstants.initializeTokenValidationError, error);
      showErrorModal(stringConstants.somethingWentWrong, stringConstants.PleaseTryAgain, stringConstants.goBack);
      setIsInitializing(false);
      throw error;
    }
  };
  const waitForSocketOpen = (socket, timeout = 8000) => {
    return new Promise((resolve, reject) => {
      if (!socket) return reject(new Error(stringConstants.socketNotInitialized));
      if (socket.readyState === WebSocket.OPEN) return resolve();

      const checkInterval = setInterval(() => {
        if (socket.readyState === WebSocket.OPEN) {
          clearInterval(checkInterval);
          resolve();
        }
      }, 100);

      setTimeout(() => {
        clearInterval(checkInterval);
        reject(new Error(stringConstants.webSocketTimeOut));
      }, timeout);
    });
  };

  const initialize = async (isRetry = false) => {

    if (!isRetry && tokenExpiryRetryCountRef.current > MAX_TOKEN_RETRIES) {
      showErrorModalTokenExpiry();
      return;
    }

    try {
      setIsInitializing(true);
      dispatch(clearMessages());
      setPage(0);
      if (!jwtToken || !userInfo.agentId || !platform) {
        console.error(stringConstants.initializeError);
        showErrorModal(stringConstants.somethingWentWrong, stringConstants.PleaseTryAgain, stringConstants.goBack);
        setIsInitializing(false);
        return;
      }
      const newToken = await validateJwt(true);
      settoken(newToken);
      let agentIdToSend = userInfo?.agentId;
      if (agentIdToSend) {
        const idStr = agentIdToSend.toString();
        if (idStr.length === 9 || idStr.length === 10) {
          agentIdToSend = idStr.slice(-7);
        }
      }
      // 🔹 fetch user config
      const response = await dispatch(getData({ token: newToken, agentId: agentIdToSend?.toLowerCase(), platform, env, retryCount: tokenExpiryRetryCountRef.current, })).unwrap();
      if (response && response.userInfo?.agentId) {
        setnavigationPage(response.statusFlag);
        setReconfigApiResponse(prev => ({ ...prev, ...response }));
        if (response.userInfo.agentId && newToken) {
          connectWebSocket(response.userInfo.agentId, newToken);
          await waitForSocketOpen(ws.current);
          await loadChatHistory(response.userInfo.agentId, page, 10, newToken);
        }
        tokenExpiryRetryCountRef.current = 0;
      }
    } catch (error) {
      console.error("Initialize error:", error);
      if (tokenExpiryRetryCountRef.current >= MAX_TOKEN_RETRIES && (error.message === stringConstants.tokenExpired || error.message === stringConstants.platformTokenExpired)) {
        showErrorModalTokenExpiry();
      }
      if (error.message === stringConstants.platformTokenExpired) {
        showErrorModal(stringConstants.failedToLogin,stringConstants.unableToAuthenticate,stringConstants.goBack)
      }
    } finally {
      setIsInitializing(false);
      dispatch(hideLoader());
    }
  };

  const safelyCleanupSocket = () => {
    cleanupWebSocket(true);
    clearResponseTimeout();
    dispatch(hideLoader());
  };
  useEffect(() => {
    initialize();
    return () => {
      safelyCleanupSocket();
    }
  }, []);
  useEffect(() => {
    if (navigationPage === stringConstants.coach) {
      resetNewMessageState();
    }
  }, [navigationPage]);

  useEffect(() => {
    let currentAppState = AppState.currentState;
    let isMounted = true; // Track mounted state
    const handleAppStateChange = (nextAppState) => {
      if (!isMounted) return;
      if (currentAppState === stringConstants.active && nextAppState.match(/inactive|background/)) {
        lastBackgroundTimeRef.current = Date.now();
        safelyCleanupSocket();
      }
      if (currentAppState.match(/inactive|background/) && nextAppState === stringConstants.active) {
        if (!ws.current || ws.current.readyState !== WebSocket.OPEN) {
          const now = Date.now();
          const delta = now - (lastBackgroundTimeRef.current || 0);
          if (delta > 60000) {
            initialize();
          } else {
            reconnectWebSocket();
          }
        }
      }
      currentAppState = nextAppState;
    };
    const subscription = AppState.addEventListener('change', handleAppStateChange);
    return () => {
      isMounted = false;
      subscription.remove();
      safelyCleanupSocket();
    };
  }, []);

  useEffect(() => {
    if (navigationPage === stringConstants.agenda && messages.length > 0) {
      const deliveredMessages = messages.filter(msg =>
        msg?.messageTo === stringConstants.user &&
        msg?.status === socketConstants.delivered &&
        msg?.isFromHistory
      );
      deliveredMessages.forEach(msg => {
        sendAcknowledgement(msg.messageId);
        updateMessageStatus({
          messageId: msg.messageId,
          status: socketConstants.read,
        });
      });
     
      
    }
  }, [navigationPage, messages]);
 
  const handleRemoveUnreadMessage = () => {
    setUnreadCount(0);
    setFirstUnreadMessageId(null);
  }
  const handleBotMessage = (data) => {
    clearResponseTimeout();
    dispatch(hideLoader());
    if (inactivityTimer) {
      clearTimeout(inactivityTimer);
    }
    setInactivityTimer(setTimeout(() => {
      cleanupWebSocket(true);
    }, timeoutConstants.inactivity));
    sendAcknowledgement(data?.messageId);
    const botMessage = formatBotMessage(data);
    setnavigationPage("agenda");
    if (!isAtBottomRef.current) {
      setFabState(prev => ({ ...prev, showFab: true, showNewMessageAlert: true, newMessageCount: prev.newMessageCount + 1 }));
    }
    dispatch(addMessage(botMessage));
  };
  const handleErrorMessage = (errorData) => {
    clearResponseTimeout();
    dispatch(updateMessageStatus({
      messageId: errorData.messageId,
      status: socketConstants.failed,
    }));
  };
  const handleAcknowledgement = (data) => {

    if (data.acknowledgement === socketConstants.received) {
      dispatch(showLoader());
      startResponseTimeout();
      dispatch(updateMessageStatus({
        messageId: data.messageId,
        status: socketConstants.read,
      }));
    }
    else if (data.acknowledgement === socketConstants.delivered) {
      dispatch(updateMessageStatus({
        messageId: data.messageId,
        status: socketConstants.received,
      }));

    }
  };
  const handleReplyClose = () => {
    setReplyIndex(0);
    setReplyMessageId(null);
    setReply(false);
  };
  const copyToClipboard = useCallback(() => {
    const androidVersion = parseInt(Platform.Version, 10);
    const textToCopy = messageObject?.message?.text
      ? splitMarkdownIntoTableAndText(messageObject?.message?.text).textPart
      : messageObject?.message?.text;

    Clipboard.setString(textToCopy);

    if (androidVersion < 33 || Platform.OS === platformName.ios) {
      setCopied(true);
      setTimeout(() => {
        setCopied(false);
        setMessageObjectId(null);
      }, 1000);
    } else {
      setMessageObjectId(null);
    }
  }, [messageObject]);


  useEffect(() => {
    if (netInfo?.isConnected) {
      if (!ws.current || ws.current.readyState !== WebSocket.OPEN) {
        const agentId = reconfigApiResponseRef.current?.userInfo?.agentId;
        if (agentId && tokenRef.current) {
          reconnectWebSocket();
        }
      }
    } else {
      cleanupWebSocket(true);
    }
  }, [netInfo?.isConnected]);

  return (
    <SafeAreaView
      style={[
        styles.container,
        { marginTop: Platform.OS === "android" ? keyboardHeight / 10 : 0 },
      ]}
    >
      <StatusBar backgroundColor={colors.primaryColors.darkBlue} />
      {Platform.OS === "android" && keyboardHeight > 100 && (
        <View
          style={{
            position: "absolute",
            zIndex: 1,
            top: -36,
            backgroundColor: colors.primaryColors.darkBlue,
            height: 40,
            width: "100%",
          }}
        />
      )}
      <ChatHeader
        reconfigApiResponse={reconfigApiResponse}
        setnavigationPage={setnavigationPage}
        navigationPage={navigationPage}
      />
      {isSharing && (
        <View style={styles.loaderContainer}>
          <VideoLoader />
        </View>
      )}

      <View style={styles.content} accessible={false}>

        {modalData.visible &&
          <View style={styles.modalContainer}>
            <ErrorModal
              visible={modalData.visible}
              title={modalData.title}
              message={modalData.message}
              buttonText={modalData.buttonText}
              action={() => {
                hideModal();
                navigation.goBack()
              }}
            />
          </View>

        }


        {!isInitializing && navigationPage === stringConstants.coach && (
          <LandingPage
            socket={socket}
            setnavigationPage={setnavigationPage}
            reconfigApiResponse={reconfigApiResponse}
            startResponseTimeout={startResponseTimeout}
            token={token}
            hasMore={hasMore}
            historyLoading={historyLoading}
            env={env}
          />
        )}
        {!isInitializing && navigationPage !== stringConstants.coach && (
          <ChatBody
            scrollViewRef={scrollViewRef}
            env={env}
            handleScroll={handleScroll}
            setDropDownType={setDropDownType}
            setMessageObjectId={setMessageObjectId}

            handleReplyMessage={handleReplyMessage}
            setReplyIndex={setReplyIndex}
            replyIndex={replyIndex}
            loadChatHistory={loadChatHistory}
            page={page}
            reconfigApiResponse={reconfigApiResponse}
            socket={socket}
            copyToClipboard={copyToClipboard}
            setCopied={setCopied}
            token={token}
            historyLoading={historyLoading}
            hasMore={hasMore}
            handleScrollEnd={onMomentumScrollEnd}
            unreadCount={unreadCount}
            firstUnreadMessageId={firstUnreadMessageId}
            removeUnreadMessage={handleRemoveUnreadMessage}
          />
        )}
      </View>
      {navigationPage !== stringConstants.coach && fabState.showFab && (
        <KeyboardAvoidingView>
          <View
            style={styles.fabWrapper}
          >
            <FabFloatingButton
              onClick={scrollToDown}
              showFab={fabState.showFab}
              showNewMessageAlert={fabState.showNewMessageAlert}
              count={fabState.newMessageCount}
              reply={reply}
            />
          </View>
        </KeyboardAvoidingView>
      )}
      <ChatFooter
        copied={copied}
        setCopied={setCopied}
        setDropDownType={setDropDownType}
        dropDownType={dropDownType}
        messageObjectId={messageObjectId}
        setnavigationPage={setnavigationPage}
        navigationPage={navigationPage}
        setMessageObjectId={setMessageObjectId}
        setReplyMessageId={setReplyMessageId}
        replyMessageId={replyMessageId}
        socket={socket}
        setReply={setReply}
        replyIndex={replyIndex}
        reply={reply}
        handleReplyClose={handleReplyClose}
        handleReplyMessage={handleReplyMessage}
        reconfigApiResponse={reconfigApiResponse}
        messages={messages}
        copyToClipboard={copyToClipboard}
        env={env}
        scrollToDown={scrollToDown}
        inactivityTimer={inactivityTimer}
        setInactivityTimer={setInactivityTimer}
        setUnreadCount={setUnreadCount}
        setFirstUnreadMessageId={setFirstUnreadMessageId}

        cleanupWebSocket={cleanupWebSocket}
        startResponseTimeout={startResponseTimeout}
        clearResponseTimeout={clearResponseTimeout}
        keyboardHeight={keyboardHeight}
        setKeyboardHeight={setKeyboardHeight}
        token={token}
        removeUnreadMessage={handleRemoveUnreadMessage}
      />
      {/* </KeyboardAvoidingView>
      </TouchableWithoutFeedback> */}
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: flex.one,
    backgroundColor: colors.primaryColors.white,
  },
  content: {
    flex: flex.one,
  },
  loaderContainer: {
    position: 'absolute',
    top: spacing.space_s0,
    left: spacing.space_s0,
    right: spacing.space_s0,
    bottom: spacing.space_s0,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
    backgroundColor: colors.loaderBackground.loaderBackgroundDark,
  },
  fabWrapper: {
    position: "absolute",
    bottom: spacing.space_10,
    right: spacing.space_m3,
  },
  modalContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  }

});
ChatPage.propTypes = {
  route: PropTypes.shape({
    params: PropTypes.shape({
      jwtToken: PropTypes.string,
      cogToken: PropTypes.string,
      userInfo: PropTypes.object,
      platform: PropTypes.string,
      env: PropTypes.string,
    }),
  }),
};